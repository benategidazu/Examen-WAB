define({
  "_themeLabel": "ערכת נושא מתקפלת",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_layout1": "פריסה 1"
});