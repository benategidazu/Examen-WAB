define({
  "_widgetLabel": "页眉控制器",
  "signin": "登录",
  "signout": "登出",
  "about": "关于",
  "signInTo": "登录到",
  "cantSignOutTip": "此功能不适用于预览模式。",
  "more": "更多"
});